// Datos de ejemplo para vehículos y agentes de policía
var vehicles = [
  {
    licenseNumber: "ABC123",
    brand: "Toyota",
    purchaseDate: "2022-01-15",
    penalized: false
  },
  {
    licenseNumber: "DEF456",
    brand: "Honda",
    purchaseDate: "2021-08-27",
    penalized: true
  },
  // Agrega más vehículos aquí si es necesario
];

var officers = [
  {
    id: "001",
    name: "Oficial 1",
    rank: "Sargento"
  },
  {
    id: "002",
    name: "Oficial 2",
    rank: "Agente"
  },
  {
    id: "003",
    name: "Oficial 3",
    rank: "Sargento"
  },
  {
    id: "004",
    name: "Oficial 4",
    rank: "Agente"
  },
  {
    id: "005",
    name: "Oficial 5",
    rank: "Sargento"
  },
  {
    id: "006",
    name: "Oficial 6",
    rank: "Agente"
  },
  {
    id: "007",
    name: "Oficial 7",
    rank: "Sargento"
  },
  {
    id: "008",
    name: "Oficial 8",
    rank: "Agente"
  },
  {
    id: "009",
    name: "Oficial 9",
    rank: "Sargento"
  },
  {
    id: "010",
    name: "Oficial 10",
    rank: "Agente"
  }
];


// Función para mostrar los vehículos en la tabla
function displayVehicles() {
  var vehicleTable = document.getElementById("vehicleTable");
  var penalizedText = "";

  for (var i = 0; i < vehicles.length; i++) {
    penalizedText = vehicles[i].penalized ? "Sí" : "No";

    var row = document.createElement("tr");
    row.innerHTML = "<td>" + vehicles[i].licenseNumber + "</td>" +
                    "<td>" + vehicles[i].brand + "</td>" +
                    "<td>" + vehicles[i].purchaseDate + "</td>" +
                    "<td>" + penalizedText + "</td>";

    vehicleTable.appendChild(row);
  }
}

// Función para mostrar los agentes de policía en la tabla
function displayOfficers() {
  var officerTable = document.getElementById("officerTable");

  for (var i = 0; i < officers.length; i++) {
    var row = document.createElement("tr");
    row.innerHTML = "<td>" + officers[i].id + "</td>" +
                    "<td>" + officers[i].name + "</td>" +
                    "<td>" + officers[i].rank + "</td>" +
                    "<td>" + getVehiclesAttended(officers[i].name) + "</td>";

    officerTable.appendChild(row);
  }
}

// Función para obtener el número de vehículos atendidos por un agente específico
var vehiclesAttended = {};
function getVehiclesAttended(agentName) {
  var attended = vehiclesAttended[agentName];
  return attended !== undefined ? attended : "";
}
function attendVehicle(officerName, licenseNumber) {
  if (vehiclesAttended[officerName] === undefined) {
    vehiclesAttended[officerName] = 1;
  } else {
    vehiclesAttended[officerName]++;
  }
  console.log(officerName + " attended vehicle with license number: " + licenseNumber);
}

// Función para agregar un nuevo vehículo a la lista
function addVehicle() {
  var licenseNumber = document.getElementById("licenseNumber").value;
  var brand = document.getElementById("brand").value;
  var purchaseDate = document.getElementById("purchaseDate").value;
  var penalized = document.getElementById("penalized").checked;

  var newVehicle = {
    licenseNumber: licenseNumber,
    brand: brand,
    purchaseDate: purchaseDate,
    penalized: penalized
  };

  vehicles.push(newVehicle);

  // Actualiza la tabla de vehículos
  var vehicleTable = document.getElementById("vehicleTable");
  var penalizedText = penalized ? "Sí" : "No";

  var row = document.createElement("tr");
  row.innerHTML = "<td>" + licenseNumber + "</td>" +
                  "<td>" + brand + "</td>" +
                  "<td>" + purchaseDate + "</td>" +
                  "<td>" + penalizedText + "</td>";

  vehicleTable.appendChild(row);

  // Limpia los campos de entrada
  document.getElementById("licenseNumber").value = "";
  document.getElementById("brand").value = "";
  document.getElementById("purchaseDate").value = "";
  document.getElementById("penalized").checked = false;

  // Sube los datos a la base de datos (llama a la función correspondiente)
  uploadDataToDatabase(newVehicle);
}

// Función para subir los datos a una base de datos
function uploadDataToDatabase(vehicle) {
  // Implementa aquí la lógica para subir los datos a tu base de datos
  // Puedes enviar una solicitud AJAX a un servidor o utilizar Firebase, MongoDB, u otra base de datos

  // Ejemplo de solicitud AJAX con jQuery:
  /* $.ajax({
       method: "POST",
       url: "url_de_tu_servidor",
       data: vehicle,
       success: function(response) {
           console.log("Datos enviados a la base de datos");
       },
       error: function(error) {
           console.log("Error al enviar los datos a la base de datos");
       }
   }); */
}

// Función para generar el PDF con la lista de vehículos
function generatePDF() {
  // Implementa aquí la generación del PDF utilizando una biblioteca como jsPDF
  // Puedes usar los datos de 'vehicles' y 'officers' para generar el contenido del PDF
}

// Llama a las funciones para mostrar los vehículos y los agentes de policía en la carga inicial de la página
displayVehicles();
displayOfficers();