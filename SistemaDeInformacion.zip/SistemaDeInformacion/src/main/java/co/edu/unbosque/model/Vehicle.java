package co.edu.unbosque.model;

public class Vehicle {
    private String licenseNumber;
    private String brand;
    private String purchaseDate;
    private boolean penalized;

    public Vehicle(String licenseNumber, String brand, String purchaseDate, boolean penalized) {
        this.licenseNumber = licenseNumber;
        this.brand = brand;
        this.purchaseDate = purchaseDate;
        this.penalized = penalized;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public String getBrand() {
        return brand;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public boolean isPenalized() {
        return penalized;
    }
}