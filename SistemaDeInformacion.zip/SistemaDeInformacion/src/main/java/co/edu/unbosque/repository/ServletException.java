package co.edu.unbosque.repository;

public class ServletException extends Exception {

}
