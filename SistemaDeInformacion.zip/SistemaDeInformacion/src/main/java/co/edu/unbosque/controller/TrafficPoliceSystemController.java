package co.edu.unbosque.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import co.edu.unbosque.model.Officer;
import co.edu.unbosque.model.Vehicle;

public class TrafficPoliceSystemController {
    private List<Vehicle> vehicles;
    private List<Officer> officers;
    private Map<String, Integer> vehiclesAttended;

    public TrafficPoliceSystemController() {
        vehicles = new ArrayList<>();
        officers = new ArrayList<>();
        vehiclesAttended = new HashMap<>();
    }

    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }

    public void addOfficer(Officer officer) {
        officers.add(officer);
    }

    public void attendVehicle(String officerName, String licenseNumber) {
        vehiclesAttended.put(officerName, vehiclesAttended.getOrDefault(officerName, 0) + 1);
        System.out.println(officerName + " attended vehicle with license number: " + licenseNumber);
    }

    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    public List<Officer> getOfficers() {
        return officers;
    }

    public Map<String, Integer> getVehiclesAttended() {
        return vehiclesAttended;
    }

    public void generatePDF() {
        // Implement your logic for generating PDF here
        System.out.println("Generating PDF...");
    }
}
