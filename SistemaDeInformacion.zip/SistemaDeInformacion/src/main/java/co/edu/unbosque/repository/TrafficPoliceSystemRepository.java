package co.edu.unbosque.repository;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


import co.edu.unbosque.controller.TrafficPoliceSystemController;
import co.edu.unbosque.model.Officer;
import co.edu.unbosque.model.Vehicle;

public class TrafficPoliceSystemRepository extends HttpServlet {
	private TrafficPoliceSystemController controller;

	public void init() throws ServletException {
		controller = new TrafficPoliceSystemController();

		// Agregar vehículos y oficiales aquí
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<html><head><title>Traffic Police System</title></head><body>");
		out.println("<h1>List of Vehicles</h1>");

		List<Vehicle> vehicles = controller.getVehicles();
		for (Vehicle vehicle : vehicles) {
			out.println("<p>License Number: " + vehicle.getLicenseNumber() + "</p>");
			out.println("<p>Brand: " + vehicle.getBrand() + "</p>");
			out.println("<p>Purchase Date: " + vehicle.getPurchaseDate() + "</p>");
			out.println("<p>Penalized: " + (vehicle.isPenalized() ? "Yes" : "No") + "</p>");
			out.println("<br>");
		}

		out.println("<h1>List of Officers</h1>");

		List<Officer> officers = controller.getOfficers();
		for (Officer officer : officers) {
			out.println("<p>Name: " + officer.getName() + "</p>");
			out.println("<p>Rank: " + officer.getRank() + "</p>");
			out.println("<br>");
		}

		out.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}
}
